package com.Nexgen.genericlib;
/**
 * 
 * @author bramesh
 *
 */

public interface AutoConstant {
	/**
	 * Used to store constants
	 */
	
	String key = "webdriver.chrome.driver";
	String value = "C:/Program Files/Java/chromedriver.exe";
	
	String propertyfilepath = "./src/test/resources/data.properties";
	String screenshotpath = "./screenshots/";

}
